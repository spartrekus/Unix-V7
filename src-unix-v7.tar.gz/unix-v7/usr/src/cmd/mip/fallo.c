# define FORT
# include "allo.c"
