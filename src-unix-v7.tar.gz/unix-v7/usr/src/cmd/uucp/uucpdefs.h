char *Thisdir = THISDIR;
char *Spool = SPOOL;
char *Myname = MYNAME;
int Debug = 0;
int Pkdebug = 0;

char *Sysfiles[] = {
	SYSFILE,
	SYSFILECR,
	NULL
};
char *Devfile = DEVFILE;
char *Dialfile = DIALFILE;
int Packflg = 0;
int Pkdrvon = 0;
int Bspeed = 150;
