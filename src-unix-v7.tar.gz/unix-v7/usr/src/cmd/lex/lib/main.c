# include "stdio.h"
main(){
yylex();
exit(0);
}
