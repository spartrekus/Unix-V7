double d_dim(a,b)
double *a, *b;
{
return( *a > *b ? *a - *b : 0);
}
