double r_cosh(x)
float *x;
{
double cosh();
return( cosh(*x) );
}
