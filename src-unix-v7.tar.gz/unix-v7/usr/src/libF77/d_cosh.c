double d_cosh(x)
double *x;
{
double cosh();
return( cosh(*x) );
}
