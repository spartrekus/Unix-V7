double d_log(x)
double *x;
{
double log();
return( log(*x) );
}
