double d_exp(x)
double *x;
{
double exp();
return( exp(*x) );
}
