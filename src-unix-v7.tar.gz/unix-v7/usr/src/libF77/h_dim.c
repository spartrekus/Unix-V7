short h_dim(a,b)
short *a, *b;
{
return( *a > *b ? *a - *b : 0);
}
