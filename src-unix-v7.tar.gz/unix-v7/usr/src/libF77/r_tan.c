double r_tan(x)
float *x;
{
double tan();
return( tan(*x) );
}
