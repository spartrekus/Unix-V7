double d_tan(x)
double *x;
{
double tan();
return( tan(*x) );
}
