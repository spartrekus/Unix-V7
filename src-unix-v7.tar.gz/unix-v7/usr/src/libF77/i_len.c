long int i_len(s, n)
char *s;
long int n;
{
return(n);
}
