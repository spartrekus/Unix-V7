double r_mod(x,y)
float *x, *y;
{
return(*x - (*y) * ( (long int) (*x / *y)) );
}
