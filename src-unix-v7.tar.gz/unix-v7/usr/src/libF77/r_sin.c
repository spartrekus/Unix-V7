double r_sin(x)
float *x;
{
double sin();
return( sin(*x) );
}
