double r_asin(x)
float *x;
{
double asin();
return( asin(*x) );
}
