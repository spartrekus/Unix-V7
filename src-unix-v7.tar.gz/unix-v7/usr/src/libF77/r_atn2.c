double r_atn2(x,y)
float *x, *y;
{
double atan2();
return( atan2(*x,*y) );
}
