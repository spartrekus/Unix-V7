double d_mod(x,y)
double *x, *y;
{
return(*x - (*y) * ( (long int) (*x / *y)) );
}
