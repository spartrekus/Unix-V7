double r_int(x)
float *x;
{
return( (long int) (*x) );
}
