/*
 * subroutine getarg(k, c)
 * returns the kth unix command argument in fortran character
 * variable argument c
*/

getarg_(n, s, ls)
long int *n;
char *s;
long int ls;
{
extern int xargc;
extern char **xargv;
char *t;
int i;

if(*n>0 && *n<xargc)
	t = xargv[*n];
else
	t = "";
for(i = 0; i<ls && *t!='\0' ; ++i)
	*s++ = *t++;
for( ; i<ls ; ++i)
	*s++ = ' ';
}
